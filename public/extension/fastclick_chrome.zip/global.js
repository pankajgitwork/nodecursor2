const SERVER_URL='http://193.203.161.49:3000';
const TARGET_URL_PATTERN=SERVER_URL+'/user/receiver';