let lastCursorX=0;
let lastCursorY=0;
let isReady=false;

// Track cursor position constantly
document.addEventListener('mousemove', function (event) {
    lastCursorX=event.clientX;
    lastCursorY=event.clientY;
}, true);

// Mark as ready when DOM is loaded
if (document.readyState==='loading') {
    document.addEventListener('DOMContentLoaded', () => {
        isReady=true;
    });
} else {
    isReady=true;
}

// Listen for messages from background script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log("Content script received message:", message);

    if (message.type==='click-at-cursor') {
        if (isReady) {
            try {
                clickAtCursor();
                sendResponse({ success: true });
                console.log("Click executed successfully");
            } catch (error) {
                console.error("Error executing click:", error);
                sendResponse({ success: false, error: error.message });
            }
        } else {
            console.warn("Content script not ready yet");
            sendResponse({ success: false, error: "Script not ready" });
        }
    }

    return true; // Keep message channel open for async response
});

/* =========== Save Login =========== */
window.addEventListener("message", event => {
    console.log("Window message received:", event);

    if (event.source!==window) {
        return; // only our page  
    }
    const msg=event.data;

    if (msg&&msg.toExtension&&msg.command==='login') {
        console.log("Processing login message");
        chrome.storage.local.set({ userLogin: msg.data })
            .then(() => {
                console.log("Login data saved");
                return chrome.runtime.sendMessage({
                    type: 'reload-extension'
                });
            })
            .then(response => {
                console.log("Extension reload requested");
            })
            .catch(err => {
                console.error("Storage or messaging error:", err);
            });
    }
});
/* =========== Save Login End =========== */

function clickAtCursor() {
    if (lastCursorX===0&&lastCursorY===0) {
        console.warn("No cursor position tracked yet");
        return;
    }

    const elementAtCursor=document.elementFromPoint(lastCursorX, lastCursorY);
    console.log(`Clicking at position (${lastCursorX}, ${lastCursorY}) on element:`, elementAtCursor);

    if (elementAtCursor) {
        const clickEvent=new MouseEvent('click', {
            view: window,
            bubbles: true,
            cancelable: true,
            clientX: lastCursorX,
            clientY: lastCursorY,
            screenX: lastCursorX+window.screenX,
            screenY: lastCursorY+window.screenY,
            button: 0,
            buttons: 1
        });

        elementAtCursor.dispatchEvent(clickEvent);

        if (elementAtCursor.click&&typeof elementAtCursor.click==='function') {
            elementAtCursor.click();
        }

        console.log("Click event dispatched");
    } else {
        console.warn("No element found at cursor position");
    }
}

// Send ready signal to background script
setTimeout(() => {
    try {
        chrome.runtime.sendMessage({ type: 'content-script-ready' });
    } catch (error) {
        // Ignore if background script is not ready
    }
}, 100);