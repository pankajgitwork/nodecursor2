// Import socket.io and global config
importScripts('socket.io.js', 'global.js');

let socket=null;
const role="receiver";

// Handle messages from content script - MUST be at top level
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type==='reload-extension') {
        chrome.runtime.reload();
        return;
    }

    if (message.type==='init-socket') {
        initSocket().then(() => {
            sendResponse({ success: true });
        }).catch(error => {
            sendResponse({ success: false, error: error.message });
        });
        return true; // Will respond asynchronously
    }

    return true;
});

// Service worker startup - check for existing login
chrome.runtime.onStartup.addListener(() => {
    console.log('Service worker started');
    initSocket();
});

chrome.runtime.onInstalled.addListener(() => {
    console.log('Extension installed/updated');
    initSocket();
});

// Initialize socket connection
async function initSocket() {
    try {
        // Clean up existing socket
        if (socket) {
            socket.disconnect();
            socket=null;
        }

        // Get login info from Chrome storage
        const result=await chrome.storage.local.get("userLogin");
        const userLogin=result.userLogin;
        const deviceId=userLogin?.deviceId||null;
        const token=userLogin?.token||null;

        if (!deviceId||!token) {
            console.log("No login credentials found");
            return;
        }

        console.log("Initializing socket connection...");

        // Create socket with minimal configuration to avoid service worker issues
        socket=io(SERVER_URL, {
            query: { token, deviceId, role },
            transports: ['websocket', 'polling'],
            // autoConnect: true,
            // forceNew: true,
            // Disable event listeners that cause issues in service workers
            closeOnBeforeunload: false
        });

        // Listen for commands
        socket.on("execute-command", handleExecuteCommand);
        socket.on("connect", () => console.log("✅ Socket connected"));
        socket.on("disconnect", (reason) => console.log("❌ Socket disconnected:", reason));
        socket.on("error", (error) => console.error("🚨 Socket error:", error));

    } catch (error) {
        console.error("Failed to initialize socket:", error);
    }
}

// Handle execute command
async function handleExecuteCommand({ command }) {
    if (command==="click-button") {
        console.log("🔥 execute-command → click-button");

        try {
            // Get active tab
            const tabs=await chrome.tabs.query({ active: true, currentWindow: true });
            if (!tabs[0]) {
                console.warn("No active tab found");
                return;
            }

            const tab=tabs[0];
            console.log("Active tab:", tab.url);

            // Check if it's a chrome:// or other restricted page
            if (tab.url.startsWith('chrome://')||
                tab.url.startsWith('chrome-extension://')||
                tab.url.startsWith('edge://')||
                tab.url.startsWith('about:')) {
                console.warn("Cannot inject content script into restricted page:", tab.url);
                return;
            }

            // Try to inject content script if it's not already there
            try {
                await chrome.scripting.executeScript({
                    target: { tabId: tab.id },
                    files: ['global.js', 'content.js']
                });
                console.log("Content script injected");

                // Wait a moment for script to initialize
                await new Promise(resolve => setTimeout(resolve, 100));
            } catch (injectionError) {
                console.log("Content script might already be injected or injection failed:", injectionError.message);
            }

            // Try to send message with retry logic
            let attempts=0;
            const maxAttempts=3;

            while (attempts<maxAttempts) {
                try {
                    await chrome.tabs.sendMessage(tab.id, {
                        type: "click-at-cursor"
                    });
                    console.log("✅ Click command sent to content script");
                    return; // Success, exit function
                } catch (error) {
                    attempts++;
                    console.log(`Attempt ${attempts} failed:`, error.message);

                    if (attempts<maxAttempts) {
                        // Wait before retry
                        await new Promise(resolve => setTimeout(resolve, 200));
                    }
                }
            }

            console.error("❌ Failed to send click command after all attempts");

        } catch (error) {
            console.error("Failed to handle execute command:", error);
        }
    }
}

// Initialize on startup
initSocket();